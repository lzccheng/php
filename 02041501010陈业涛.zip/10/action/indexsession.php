<?php 
include "../../action/isLogin.php";
echo '1';



 ?>