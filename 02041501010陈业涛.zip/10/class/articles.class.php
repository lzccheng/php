<?php 
   class articles extends Table
   {
   	  

     
   	 
   }






 ?>