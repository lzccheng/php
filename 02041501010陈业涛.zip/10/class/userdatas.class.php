<?php 
   class userdatas extends Table
   {
   	  

     
   	 
   }


 ?>