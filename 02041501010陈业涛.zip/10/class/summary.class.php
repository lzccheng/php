<?php 
   class summary extends Table
   {
   	  

     
   	 
   }






 ?>