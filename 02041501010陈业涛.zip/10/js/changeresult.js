var resultcontent=document.getElementById('resultcontent');
	var a=resultcontent.getElementsByClassName('tr');
	var select1=resultcontent.getElementsByClassName('select1');	
	// var time=document.getElementsByClassName('time');
	// var start=document.getElementById('start');
	// var dele=document.getElementById('delete');
	// var add=document.getElementById('add');
	// var flag=1;
	// var record1=document.getElementsByClassName('record1');
	// var  interval;

// window.onload=function(){
// 	for (var i = 0; i< select1.length; i++) {

// 		var select1[i].index=i;
		
// 		select1[i].onchange=function()
// 		{	

// 				  var dataId=a[this.index].id;
// 				 // var dataId=a[this.index].id;
// 				   var result=this.value;
// 				  // getrecord(dataId,result);
// 				  alert(dataId);
// 		}

// // alert(select1.length);
			
// 	}
// }
	
// for(i=0;i<a.length;i++)

// 			{

// 				a[i].index=i;
// 				a[i].onclick=function()
// 				{
// 					// var value1=a[i].cells[0].getElementsName('input')[0].value;

						
// 						var value=this.id;
						

// 				}
// 			}


